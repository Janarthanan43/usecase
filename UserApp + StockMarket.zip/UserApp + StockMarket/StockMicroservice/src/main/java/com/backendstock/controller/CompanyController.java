package com.backendstock.controller;

import com.backendstock.DTOs.CompanyResponseDTO;
import com.backendstock.exception.CompanyNotFound;
import com.backendstock.feign.AuthorizeClient;
import com.backendstock.kafka.producer;
import com.backendstock.model.Company;
import com.backendstock.service.CompanyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/v1.0/market/company")

public class CompanyController {

    @Autowired
    private producer pro;
    private CompanyService companyService;
    private AuthorizeClient authorizeClient;

    @Autowired
    public CompanyController(CompanyService companyService, AuthorizeClient authorizeClient) {
        this.companyService = companyService;
        this.authorizeClient = authorizeClient;
    }

    @GetMapping("/info/{companyCode}")
    public ResponseEntity<?> getCompanyInfo(@PathVariable Long companyCode,@RequestHeader ("Authorization") String token) {
        if(authorizeClient.authorize(token)) {
            Optional<CompanyResponseDTO> company = companyService.getCompanyByID(companyCode);
            pro.message("Information Fetched Successfully");
            return ResponseEntity.ok(company);
        }
        else
        {
            return new ResponseEntity<>("User not Authenticated",HttpStatus.BAD_REQUEST);
        }

    }

    @GetMapping("/getAll")
    public ResponseEntity<?> getAllCompanies(@RequestHeader ("Authorization") String token) {
        if(authorizeClient.authorize(token)) {
            List<CompanyResponseDTO> companies = companyService.getAllCompanies();
            pro.message("Details Fetched Successfully");
            return ResponseEntity.ok(companies);
        }
        else
        {
            return new ResponseEntity<>("User not Authenticated",HttpStatus.BAD_REQUEST);
        }
    }

    @PostMapping("/register")
    public ResponseEntity<?> RegisterCompany(@RequestBody Company company,@RequestHeader ("Authorization") String token) {
        if((authorizeClient.authorize(token)) && (authorizeClient.getrole(token).equalsIgnoreCase("admin")))
        {
            Company c = companyService.RegisterCompany(company);
            pro.message("Registered Successfully");
            return ResponseEntity.ok(c);
        }
        else
        {
        return new ResponseEntity<>("Sorry,Can only be Accessed by Admin",HttpStatus.BAD_REQUEST);
        }
    }

    @PutMapping("/put/{companyCode}")
    public ResponseEntity<String> updateCompany(@PathVariable long companyCode,@RequestBody Company company,@RequestHeader ("Authorization") String token)
    {
        try
        {
            if((authorizeClient.authorize(token)) && (authorizeClient.getrole(token).equalsIgnoreCase("admin"))) {
                companyService.UpdateCompany(companyCode, company);
                pro.message("Company Details Updated Successfully");
                return ResponseEntity.ok("Company Details Updated Successfully");
            }
            else
            {
                return new ResponseEntity<>("Sorry,Can only be Accessed by Admin",HttpStatus.BAD_REQUEST);
            }
        }
        catch (CompanyNotFound e)
        {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Company Not Found with ID:"+companyCode);
        }
    }

    @DeleteMapping("/delete/{companyCode}")
    public ResponseEntity<?> DeleteCompany(@PathVariable long companyCode,@RequestHeader ("Authorization") String token)
    {
        if((authorizeClient.authorize(token)) && (authorizeClient.getrole(token).equalsIgnoreCase("admin"))) {
            pro.message("Deleted Successfully");
            return ResponseEntity.ok(companyService.deleteCompany(companyCode));
        }
        else
        {
            return new ResponseEntity<>("Sorry,Can only be Accessed by Admin",HttpStatus.BAD_REQUEST);
        }
    }
}
