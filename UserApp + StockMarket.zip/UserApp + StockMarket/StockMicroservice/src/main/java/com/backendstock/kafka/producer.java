package com.backendstock.kafka;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

@Service
public class producer
{
    public static final String topic ="auth";

    private KafkaTemplate<String, String> kafkaTemplate;

    public producer(KafkaTemplate<String, String> kafkaTemplate) {
        this.kafkaTemplate = kafkaTemplate;
    }

    public void message(String message){
        System.out.println(String.format("kafka Message sent from: %s", message));
        kafkaTemplate.send(topic, message);
    }
}