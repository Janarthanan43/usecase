package com.backendstock.exception;

public class CompanyNotFound extends RuntimeException{
    public CompanyNotFound(String Message)
    {
        super(Message);
    }
}
