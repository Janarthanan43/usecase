package com.backendstock.controller;
import com.backendstock.DTOs.CompanyResponseDTO;
import com.backendstock.exception.CompanyNotFound;
import com.backendstock.feign.AuthorizeClient;
import com.backendstock.model.Company;
import com.backendstock.service.CompanyService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import java.util.Collections;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

class CompanyControllerTest {
    @Mock
    private CompanyService companyService;
    @Mock
    private AuthorizeClient authorizeClient;
    @InjectMocks
    private CompanyController companyController;
    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }


    @Test
    void getAllCompanies_WithInvalidToken_ReturnsBadRequest() {
        when(authorizeClient.authorize(anyString())).thenReturn(false);
        ResponseEntity<?> response = companyController.getAllCompanies("invalid-token");
        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        verify(authorizeClient, times(1)).authorize(anyString());
        verify(companyService, never()).getAllCompanies();
    }

    @Test
    void registerCompany_WithInvalidRole_ReturnsBadRequest() {
        when(authorizeClient.authorize(anyString())).thenReturn(true);
        when(authorizeClient.getrole(anyString())).thenReturn("user");
        ResponseEntity<?> response = companyController.RegisterCompany(new Company(), "valid-token");
        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        verify(authorizeClient, times(1)).authorize(anyString());
        verify(authorizeClient, times(1)).getrole(anyString());
        verify(companyService, never()).RegisterCompany(any(Company.class));
    }


    @Test
    void updateCompany_WithInvalidRole_ReturnsBadRequest() {
        when(authorizeClient.authorize(anyString())).thenReturn(true);
        when(authorizeClient.getrole(anyString())).thenReturn("user");
        ResponseEntity<String> response = companyController.updateCompany(1L, new Company(), "valid-token");
        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        verify(authorizeClient, times(1)).authorize(anyString());
        verify(authorizeClient, times(1)).getrole(anyString());
        verify(companyService, never()).UpdateCompany(anyLong(), any(Company.class));
    }
    @Test
    void updateCompany_WhenCompanyNotFound_ReturnsNotFound() {
        when(authorizeClient.authorize(anyString())).thenReturn(true);
        when(authorizeClient.getrole(anyString())).thenReturn("admin");
        doThrow(new CompanyNotFound("Company not found")).when(companyService).UpdateCompany(anyLong(), any(Company.class));
        ResponseEntity<String> response = companyController.updateCompany(1L, new Company(), "valid-token");
        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
        assertEquals("Company Not Found with ID:1", response.getBody());
        verify(authorizeClient, times(1)).authorize(anyString());
        verify(authorizeClient, times(1)).getrole(anyString());
        verify(companyService, times(1)).UpdateCompany(anyLong(), any(Company.class));
    }

    @Test
    void deleteCompany_WithInvalidRole_ReturnsBadRequest() {
        when(authorizeClient.authorize(anyString())).thenReturn(true);
        when(authorizeClient.getrole(anyString())).thenReturn("user");
        ResponseEntity<?> response = companyController.DeleteCompany(1L, "valid-token");
        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        verify(authorizeClient, times(1)).authorize(anyString());
        verify(authorizeClient, times(1)).getrole(anyString());
        verify(companyService, never()).deleteCompany(anyLong());
    }
}